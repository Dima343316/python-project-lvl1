#!/usr/bin/env python
from brain_games.game.brain_gcd import gcd_1


def main():
    if __name__ == '__main__':
        print(gcd_1())
        main()
