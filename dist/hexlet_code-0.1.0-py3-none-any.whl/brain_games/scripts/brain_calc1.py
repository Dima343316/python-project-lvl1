#!/usr/bin/env python
from brain_games.game.brain_calc import calc_1


def main():
    if __name__ == '__main__':
        print(calc_1())
        main()
