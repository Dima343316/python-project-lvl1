#!/usr/bin/env python
from brain_games.game.brain_even import even_numbers


def main():
    if __name__ == '__main__':
        print(even_numbers())
        main()
