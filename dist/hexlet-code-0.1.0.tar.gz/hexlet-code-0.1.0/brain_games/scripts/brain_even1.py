#!/usr/bin/env python
from brain_games.game.brain_even import even_numbers

def main():
    print(even_numbers())

if __name__ == '__main__':
    main()          
