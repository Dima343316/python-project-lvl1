#!/usr/bin/env python
from brain_games.game import brain_calc


def main():
    brain_calc.calc_1()


if __name__ == '__main__':
    main()
