#!/usr/bin/env python
from brain_games.game import brain_even


def main():
    brain_even.even_numbers_11()


if __name__ == '__main__':
    main()
