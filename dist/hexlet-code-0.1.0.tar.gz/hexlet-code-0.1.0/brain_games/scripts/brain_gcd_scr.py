#!/usr/bin/env python
from brain_games.game import brain_gcd


def main():
    brain_gcd.gcd_1()


if __name__ == '__main__':
    main()
