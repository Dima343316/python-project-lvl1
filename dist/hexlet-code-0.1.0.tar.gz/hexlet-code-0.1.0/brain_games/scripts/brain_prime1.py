#!/usr/bin/env python
from brain_games.game.brain_prime import start_prime


def main():
    if __name__ == '__main__':
        print(start_prime())
        main()
