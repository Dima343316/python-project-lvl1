#!/usr/bin/env python
from brain_games.game import brain_progression


def main():
    brain_progression.progress()


if __name__ == '__main__':
    main()
