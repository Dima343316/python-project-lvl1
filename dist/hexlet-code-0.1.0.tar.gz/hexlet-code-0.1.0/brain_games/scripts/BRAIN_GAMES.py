#!/usr/bin/env python
from brain_games.game.cli import welcome_user


def main():
    if __name__ == '__main__':
       print(welcome_user())
       main()
