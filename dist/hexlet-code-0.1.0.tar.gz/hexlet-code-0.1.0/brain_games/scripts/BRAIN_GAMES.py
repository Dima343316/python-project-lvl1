#!/usr/bin/env python
from brain_games.scripts.cli import welcome_user
def main():
    if __name__=='__main__':
        welcome_user()
        main()
